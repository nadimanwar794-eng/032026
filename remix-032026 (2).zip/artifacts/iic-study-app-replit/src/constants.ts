
// @ts-nocheck
import { Subject } from './types';
import { FULL_SYLLABUS } from './utils/full_syllabus_data';
// @ts-ignore
// import { COMPETITION_DATA } from './competition_syllabus';

export const APP_VERSION = "1.0.1";
export const BUILD_NUMBER = "20260716.01";
export const SUPPORT_PHONE = "8227070298"; // Admin support number — update here instead of in code
export const ADMIN_EMAIL = "nadiman0636indo@gmail.com";
export const SUPPORT_EMAIL = "nadiman0636indo@gmail.com";

export const DEFAULT_CONTENT_INFO_CONFIG = {
    freeNotes: {
        enabled: true,
        title: "Strong Concepts. Clear Theory. Exam-Ready Notes.",
        details: "NCERT + syllabus aligned structured notes\nEasy language, clear explanation\nIdeal for first reading & basic exam preparation",
        bestFor: "School / college students\nFirst-time learners\nFoundation building"
    },
    premiumNotes: {
        enabled: true,
        title: "Think Like a Topper. Write Like an Examiner.",
        details: "Deep analytical notes with answer-writing framework\nCase studies, criticism & evaluation included\nDesigned for high-scoring answers in competitive exams",
        bestFor: "Serious aspirants\nCompetition / State PSC / advanced exams\nStudents targeting top marks"
    },
    freeVideo: {
        enabled: true,
        title: "Concept Clarity & Foundation Building",
        details: "Easy to understand explanations\nCovers syllabus basics thoroughly\nGood for revision and concept grasping",
        bestFor: "School students\nBasic understanding\nQuick Revision"
    },
    premiumVideo: {
        enabled: true,
        title: "Advanced Analysis & Exam Strategy",
        details: "In-depth topic coverage with advanced examples\nExam-oriented problem solving tricks\nDeep dive into complex concepts",
        bestFor: "Competitive exam aspirants\nAdvanced learners\nToppers targeting 100%"
    }
};

export const DEFAULT_APP_FEATURES = [
    { id: 'f1', title: 'Smart Video Lectures', enabled: true, order: 1 },
    { id: 'f2', title: 'PDF Notes Library', enabled: true, order: 2 },
    { id: 'f3', title: 'MCQ Practice Zone', enabled: true, order: 3 },
    { id: 'f4', title: 'Weekly Tests', enabled: false, order: 4 },
    { id: 'f5', title: 'Leaderboard', enabled: true, order: 5 },
    { id: 'f6', title: 'Engagement Rewards', enabled: true, order: 6 },
    { id: 'f7', title: 'Universal Chat', enabled: false, order: 7 },
    { id: 'f8', title: 'Private Admin Support', enabled: true, order: 8 },
    { id: 'f9', title: 'Spin Wheel Game', enabled: true, order: 9 },
    { id: 'f10', title: 'Credit System', enabled: true, order: 10 },
    { id: 'f11', title: 'Subscription Plans', enabled: true, order: 11 },
    { id: 'f12', title: 'Store', enabled: true, order: 12 },
    { id: 'f13', title: 'Profile Customization', enabled: true, order: 13 },
    { id: 'f14', title: 'Study Timer', enabled: true, order: 14 },
    { id: 'f15', title: 'Streak System', enabled: true, order: 15 },
    { id: 'f16', title: 'User Inbox', enabled: true, order: 16 },
    { id: 'f17', title: 'Admin Dashboard', enabled: true, order: 17 },
    { id: 'f18', title: 'Content Manager', enabled: true, order: 18 },
    { id: 'f19', title: 'Bulk Upload', enabled: true, order: 19 },
    { id: 'f20', title: 'Security System', enabled: true, order: 20 },
    { id: 'f21', title: 'Performance History', enabled: true, order: 21 },
    { id: 'f22', title: 'Dark/Light Mode', enabled: true, order: 22 },
    { id: 'f23', title: 'Responsive Design', enabled: true, order: 23 },
    { id: 'f24', title: 'PDF Watermarking', enabled: true, order: 24 },
    { id: 'f25', title: 'Auto-Sync', enabled: true, order: 25 },
    { id: 'f26', title: 'Offline Capabilities', enabled: true, order: 26 },
    { id: 'f28', title: 'Passwordless Login', enabled: true, order: 28 },
    { id: 'f29', title: 'Custom Subjects', enabled: true, order: 29 },
    { id: 'f30', title: 'Gift Codes', enabled: true, order: 30 },
    { id: 'f31', title: 'Featured Shortcuts', enabled: true, order: 31 },
    { id: 'f32', title: 'Notice Board', enabled: true, order: 32 },
    { id: 'f33', title: 'Startup Ad', enabled: true, order: 33 },
    { id: 'f34', title: 'External Apps', enabled: true, order: 34 },
    { id: 'f35', title: 'Activity Log', enabled: true, order: 35 },
    { id: 'f36', title: 'AI Question Generator', enabled: true, order: 36 },
    { id: 'f37', title: 'Payment Gateway Integration', enabled: true, order: 37 },
    { id: 'f38', title: 'Class Management', enabled: true, order: 38 },
    { id: 'f39', title: 'Stream Support', enabled: true, order: 39 },
    { id: 'f40', title: 'Board Support', enabled: true, order: 40 },
    { id: 'f41', title: 'Multi-Language Support', enabled: true, order: 41 },
    { id: 'f42', title: 'Fast Search', enabled: true, order: 42 },
    { id: 'f43', title: 'Recycle Bin', enabled: true, order: 43 },
    { id: 'f44', title: 'Data Backup', enabled: true, order: 44 },
    { id: 'f45', title: 'Deployment Tools', enabled: true, order: 45 },
    { id: 'f46', title: 'Role Management', enabled: true, order: 46 },
    { id: 'f47', title: 'Ban System', enabled: true, order: 47 },
    { id: 'f48', title: 'Impersonation Mode', enabled: true, order: 48 },
    { id: 'f49', title: 'Daily Goals', enabled: true, order: 49 },
    { id: 'f50', title: 'Visual Analytics', enabled: true, order: 50 }
];

export const DEFAULT_SUBJECTS = {
  physics: { id: 'physics', name: 'Physics', icon: 'physics', color: 'bg-white text-slate-700' },
  chemistry: { id: 'chemistry', name: 'Chemistry', icon: 'flask', color: 'bg-white text-slate-700' },
  biology: { id: 'biology', name: 'Biology', icon: 'bio', color: 'bg-white text-slate-700' },
  math: { id: 'math', name: 'Mathematics', icon: 'math', color: 'bg-white text-slate-700' },
  history: { id: 'history', name: 'History', icon: 'history', color: 'bg-white text-slate-700' },
  geography: { id: 'geography', name: 'Geography', icon: 'geo', color: 'bg-white text-slate-700' },
  polity: { id: 'polity', name: 'Political Science', icon: 'gov', color: 'bg-white text-slate-700' },
  economics: { id: 'economics', name: 'Economics', icon: 'social', color: 'bg-white text-slate-700' },
  business: { id: 'business', name: 'Business Studies', icon: 'business', color: 'bg-white text-slate-700' },
  accounts: { id: 'accounts', name: 'Accountancy', icon: 'accounts', color: 'bg-white text-slate-700' },

  lucent: { id: 'lucent', name: 'Lucent Book', icon: 'book', color: 'bg-white text-slate-700' },
  speedyScience: { id: 'speedyScience', name: 'Speedy Science', icon: 'science', color: 'bg-white text-slate-700' },
  speedySocialScience: { id: 'speedySocialScience', name: 'Speedy Social Science', icon: 'social', color: 'bg-white text-slate-700' },
  sarSangrah: { id: 'sarSangrah', name: 'Sar Sangrah', icon: 'history', color: 'bg-white text-slate-700' },
  mcq: { id: 'mcq', name: 'MCQ Practice', icon: 'mcq', color: 'bg-white text-slate-700' },
  science: { id: 'science', name: 'Science', icon: 'science', color: 'bg-white text-slate-700' },
  sst: { id: 'sst', name: 'Social Science', icon: 'geo', color: 'bg-white text-slate-700' }
};

// Lucent GK subject categories (Competition mode) — the single source of truth
// shared by Book Notes Manager (AdminDashboard) and Revision Hub's Class MCQ
// Manager (AdminClassMcqManager), so both always show the same subject set.
export const LUCENT_SUBJECT_OPTIONS_BASE: { id: string; name: string }[] = [
  { id: 'ancient_india', name: 'प्राचीन भारत' },
  { id: 'medieval_india', name: 'मध्यकालीन भारत' },
  { id: 'modern_india', name: 'आधुनिक भारत' },
  { id: 'world_history', name: 'विश्व इतिहास' },
  { id: 'world_geography', name: 'विश्व का भूगोल' },
  { id: 'india_geography', name: 'भारत का भूगोल' },
  { id: 'environment_ecology', name: 'पर्यावरण एवं पारिस्थितिकी' },
  { id: 'indian_economy', name: 'भारतीय अर्थव्यवस्था' },
  { id: 'indian_constitution', name: 'भारतीय संविधान' },
  { id: 'physics', name: 'भौतिक विज्ञान' },
  { id: 'chemistry', name: 'रसायन विज्ञान' },
  { id: 'biology', name: 'जीव विज्ञान' },
  { id: 'science_technology', name: 'विज्ञान एवं प्रौद्योगिकी' },
  { id: 'computer', name: 'कंप्यूटर' },
  { id: 'art_culture', name: 'कला एवं संस्कृति' },
  { id: 'sports', name: 'खेल-कूद' },
  { id: 'miscellaneous', name: 'विविध' },
];

// Competition subject options = built-in Lucent subjects (minus admin-hidden ones)
// plus any admin-defined custom subjects. Mirrors AdminDashboard's derivation so
// Revision Hub's Class MCQ Manager always matches Book Notes Manager exactly.
export const getLucentSubjectOptions = (settings: any): { id: string; name: string }[] => {
  const hiddenIds: Set<string> = new Set((settings?.hiddenLucentSubjectIds || []) as string[]);
  const customSubjects: { id: string; name: string }[] = (settings?.customLucentSubjects || []).filter(
    (s: any) => s && s.id && s.name,
  );
  return [
    ...LUCENT_SUBJECT_OPTIONS_BASE.filter(s => !hiddenIds.has(s.id)),
    ...customSubjects,
  ];
};

// Class 6-12 subject options for a given class — union of subjects across all
// streams (Science/Commerce/Arts/none), deduped by id. Mirrors the derivation
// used by Class 6-12 Notes Manager so every class-level subject picker in the
// admin (including Revision Hub's Class MCQ Manager) shows identical subjects.
export const getClassSubjectOptions = (classLevel: string): { id: string; name: string }[] => {
  try {
    const seen = new Set<string>();
    const results: { id: string; name: string }[] = [];
    ([`Science`, `Commerce`, `Arts`, null] as (string | null)[]).forEach(stream => {
      getSubjectsList(classLevel, stream).forEach(s => {
        if (!seen.has(s.id)) { seen.add(s.id); results.push({ id: s.id, name: s.name }); }
      });
    });
    return results.length > 0 ? results : [{ id: 'science', name: 'Science' }];
  } catch {
    return [{ id: 'science', name: 'Science' }];
  }
};

export const getSubjectsList = (classLevel: string, stream: string | null, board?: string, settingsObj?: any): Subject[] => {
  const isSenior = ['11', '12'].includes(classLevel);
  let pool = { ...DEFAULT_SUBJECTS };
  try {
      const stored = localStorage.getItem('nst_custom_subjects_pool');
      if (stored) {
          pool = JSON.parse(stored);
      }
  } catch (e) {
      console.error("Error loading dynamic subjects", e);
  }

  // Load admin-managed Revision Hub subjects from system settings (Firebase-synced)
  let hiddenDefaultSubjects: string[] = [];
  let adminRevisionSubjects: Array<{ id: string; name: string; icon: string; classLevels: string[]; streams: string[] }> = [];
  try {
      const settingsRaw = localStorage.getItem('nst_system_settings');
          const s = settingsObj || (settingsRaw ? JSON.parse(settingsRaw) : null);
      if (s) {
          // const s = JSON.parse(settingsRaw);
          hiddenDefaultSubjects = Array.isArray(s.hiddenDefaultSubjects) ? s.hiddenDefaultSubjects : [];
          adminRevisionSubjects = Array.isArray(s.revisionSubjects) ? s.revisionSubjects : [];
      }
  } catch (e) { /* ignore */ }

  const allKeys = Object.keys(pool);
  const coreKeys = Object.keys(DEFAULT_SUBJECTS);
  const customKeys = allKeys.filter(k => !coreKeys.includes(k));

  let selectedSubjects: Subject[] = [];
  const commonSubjects: Subject[] = []; // Removed english, hindi, computer

  if (classLevel === 'COMPETITION') {
      selectedSubjects = [
          pool.lucent,
          pool.speedyScience,
          pool.speedySocialScience,
          pool.sarSangrah,
          pool.mcq,
      ].filter(Boolean);

      // Admin-defined Custom Books (Sar Sangrah / Speedy ki tarah). Stored under
      // SystemSettings.customBooks (mirrored to localStorage for fast read).
      // Each becomes a subject card on the Competition home, opening a flat
      // page-wise list of notes/MCQs in StudentDashboard.
      try {
          const settingsRaw = localStorage.getItem('nst_system_settings');
          const s = settingsObj || (settingsRaw ? JSON.parse(settingsRaw) : null);
          const finalSettingsObj = settingsObj || (settingsRaw ? JSON.parse(settingsRaw) : null);
          const customBooks: Array<{ id: string; name: string }> = Array.isArray(finalSettingsObj?.customBooks)
              ? finalSettingsObj.customBooks
              : [];
          const palette = ['bg-white text-slate-700', 'bg-white text-slate-700', 'bg-white text-slate-700', 'bg-white text-slate-700', 'bg-white text-slate-700'];
          customBooks.forEach((b, i) => {
              if (b && b.id && b.name) {
                  selectedSubjects.push({
                      id: b.id,
                      name: b.name,
                      icon: 'book',
                      color: palette[i % palette.length],
                  });
              }
          });
      } catch (e) { /* ignore */ }
  }
  else if (!isSenior) {
      const isClass9or10 = ['9', '10'].includes(classLevel);
      const isClass6to8 = ['6', '7', '8'].includes(classLevel);

      let juniorSubjects: Subject[] = [pool.math];

      if (isClass9or10) {
          juniorSubjects.push(
              pool.physics,
              pool.chemistry,
              pool.biology,
              pool.history,
              pool.geography,
              pool.polity,
              pool.economics
          );
      } else if (isClass6to8) {
          juniorSubjects.push(
              pool.science, // Kept as general science for 6-8 based on prompt request.
              pool.history,
              pool.geography,
              pool.polity
          );
      } else {
          juniorSubjects.push(pool.science, pool.sst);
      }

      selectedSubjects = juniorSubjects.filter(Boolean);
  }
  else {
      if (stream === 'Science') {
          selectedSubjects = [pool.physics, pool.chemistry, pool.math, pool.biology, ...commonSubjects];
      } else if (stream === 'Commerce') {
          selectedSubjects = [pool.accounts, pool.business, pool.economics, pool.math, ...commonSubjects];
      } else if (stream === 'Arts') {
          selectedSubjects = [pool.history, pool.geography, pool.polity, pool.economics, ...commonSubjects];
      }
      selectedSubjects = selectedSubjects.filter(Boolean);
  }

  // Filter out hidden default subjects (admin-managed via SystemSettings)
  selectedSubjects = selectedSubjects.filter(s => !hiddenDefaultSubjects.includes(s.id));

  customKeys.forEach(key => {
      if (pool[key]) selectedSubjects.push(pool[key]);
  });

  // Append admin-managed revision subjects (Firebase-backed, match classLevel/stream)
  adminRevisionSubjects.forEach(sub => {
      if (!sub.id || !sub.name) return;
      const levelsMatch = !sub.classLevels?.length || sub.classLevels.includes(classLevel) || sub.classLevels.includes('all');
      const streamMatch = !sub.streams?.length || sub.streams.includes('all') || !stream || sub.streams.includes(stream);
      if (levelsMatch && streamMatch) {
          selectedSubjects.push({ id: sub.id, name: sub.name, icon: sub.icon || 'book', color: 'bg-white text-slate-700' });
      }
  });

  if (board === 'BSEB' || board === 'NCERT_HI') {
      const hindiMap: Record<string, string> = {
          'Physics': 'भौतिकी',
          'Chemistry': 'रसायन शास्त्र',
          'Biology': 'जीव विज्ञान',
          'Mathematics': 'गणित',
          'History': 'इतिहास',
          'Geography': 'भूगोल',
          'Political Science': 'राजनीति विज्ञान',
          'Economics': 'अर्थशास्त्र',
          'Business Studies': 'व्यवसाय अध्ययन',
          'Accountancy': 'लेखाशास्त्र',
          'Science': 'विज्ञान',
          'Social Science': 'सामाजिक विज्ञान',
          'English': 'अंग्रेजी',
          'Hindi': 'हिन्दी',
          'Sanskrit': 'संस्कृत',
          'Computer Science': 'कंप्यूटर विज्ञान'
      };

      selectedSubjects = selectedSubjects.map(s => ({
          ...s,
          name: hindiMap[s.name] || s.name
      }));
  }

  return selectedSubjects;
};

export const STATIC_SYLLABUS: Record<string, string[]> = FULL_SYLLABUS;

export const ADMIN_PERMISSIONS = [
    'VIEW_DASHBOARD', 'VIEW_USERS', 'MANAGE_USERS', 'DELETE_USERS',
    'MANAGE_SUBS', 'GRANT_FREE_SUB', 'VIEW_REVENUE',
    'MANAGE_CONTENT', 'UPLOAD_VIDEO', 'UPLOAD_PDF', 'CREATE_MCQ', 'CREATE_TEST', 'MANAGE_AI_NOTES',
    'MANAGE_SETTINGS', 'EDIT_APP_NAME', 'EDIT_THEME', 'MANAGE_API_KEYS',
    'MANAGE_NOTICES', 'SEND_NOTIFICATIONS', 'MANAGE_CHAT', 'BAN_USERS',
    'VIEW_LOGS', 'VIEW_DATABASE', 'MANAGE_GIFT_CODES', 'MANAGE_SUB_ADMINS',
    'MANAGE_REWARDS', 'MANAGE_STORE', 'MANAGE_PACKAGES', 'MANAGE_PLANS',
    'MANAGE_ADS', 'MANAGE_EXTERNAL_APPS', 'MANAGE_SYLLABUS',
    'VIEW_DEMANDS', 'APPROVE_LOGIN_REQS', 'DEPLOY_APP', 'RESET_SYSTEM',
    'MANAGE_PREMIUM_VIDEOS', 'MANAGE_APP_SOUL', 'MANAGE_FEATURES'
];

export const ALL_APP_FEATURES = [
    { id: 'MY_COURSE', title: 'My Course', enabled: true },
    { id: 'MY_ANALYSIS', title: 'My Analysis', enabled: true },
    { id: 'STUDY_GOAL_PERF', title: 'Study Goal Performance', enabled: true },
    { id: 'STUDENT_MENU', title: 'Student Menu', enabled: true },
    { id: 'HISTORY_PAGE', title: 'History Page', enabled: true },
    { id: 'PROFILE_PAGE', title: 'Profile Page', enabled: true },
    { id: 'INBOX', title: 'Inbox', enabled: true },
    { id: 'INBOX_MARKSHEET', title: 'Inbox Marksheet', enabled: true },
    { id: 'MY_PLAN', title: 'My Plan', enabled: true },
    { id: 'FLOATING_BTN', title: 'Floating Button', enabled: true },
    { id: 'STORE_PAGE', title: 'Store Page', enabled: true },
    { id: 'UNIVERSAL_INFO', title: 'Universal Information', enabled: true },
    { id: 'REVISION_HUB', title: 'Revision Hub (Base)', enabled: true },
    { id: 'REVISION_HUB_FREE', title: 'Free Revision Hub', enabled: true },
    { id: 'REVISION_HUB_PREMIUM', title: 'Premium Revision Hub', enabled: true },
    { id: 'TODAY_TASK', title: 'Today Task', enabled: true },
    { id: 'MCQ_TAB', title: 'MCQ Tab (Revision)', enabled: true },
    { id: 'MISTAKE_TAB', title: 'Mistake Tab', enabled: true },
    { id: 'WEEK_STRENGTH', title: 'Week Analysis', enabled: true },
    { id: 'AVG_STRENGTH', title: 'Average Strength', enabled: true },
    { id: 'STRONG_STRENGTH', title: 'Strong Strength', enabled: true },
    { id: 'AI_PLAN', title: 'AI Plan', enabled: true },
    { id: 'YESTERDAY_REPORT', title: 'Yesterday Report', enabled: true },
    { id: 'START_REVISION', title: 'Start Revision Button', enabled: true },
    { id: 'MASTERY_30_DAY', title: '30 Day Mastery', enabled: true },
    { id: 'WHATS_NEW_VIDEO', title: 'Whats New Video Lectures', enabled: true },
    { id: 'FREE_VIDEOS', title: 'Free Videos', enabled: true },
    { id: 'PREMIUM_VIDEOS', title: 'Premium Videos', enabled: true },
    { id: 'VIDEO_LIB', title: 'Video Library', enabled: true },
    { id: 'NOTES_LIB', title: 'Notes Library', enabled: true },
    { id: 'FREE_NOTES', title: 'Free Notes', enabled: true },
    { id: 'PREMIUM_NOTES', title: 'Premium Notes', enabled: true },
    { id: 'TOPIC_NOTES', title: 'Topic Notes', enabled: true },
    { id: 'RECOMMEND_NOTES', title: 'Recommended Notes', enabled: true },
    { id: 'MCQ_LIB', title: 'MCQ Library', enabled: true },
    { id: 'FREE_MCQ', title: 'Free MCQ', enabled: true },
    { id: 'PREMIUM_MCQ', title: 'Premium MCQ', enabled: true },
    { id: 'MISTAKES_PAGE', title: 'Mistakes Page', enabled: true },
    { id: 'RECENT_TESTS', title: 'Recent Tests', enabled: true },
    { id: 'AUDIO_LIB', title: 'Audio Library', enabled: true },
    { id: 'TTS_FEATURE', title: 'Text-to-Speech (TTS)', enabled: true },
    { id: 'AI_HUB_BANNER', title: 'AI Hub Banner', enabled: true },
    { id: 'DEEP_ANALYSIS', title: 'Deep Analysis', enabled: true },
    { id: 'AI_CHAT_TURBO', title: 'AI Chat Turbo', enabled: true },
    { id: 'AI_INSIGHT_MAP', title: 'AI Insight Roadmap', enabled: true },
    { id: 'PREMIUM_ANALYSIS', title: 'Premium Analysis', enabled: true },
    { id: 'PLAY_GAME', title: 'Play Game', enabled: true },
    { id: 'REDEEM_PRIZES', title: 'Redeem Prizes', enabled: true },
    { id: 'DISCOUNT_EVENT', title: 'Discount Event', enabled: true },
    { id: 'ACCURACY_STAT', title: 'Accuracy Stat', enabled: true },
    { id: 'SPEED_STAT', title: 'Speed Stat', enabled: true },
    { id: 'PERF_TREND', title: 'Performance Trend', enabled: true },
    { id: 'STRONG_AREA', title: 'Strong Areas', enabled: true },
    { id: 'AREA_IMPROVING', title: 'Area Improving', enabled: true },
    { id: 'FOCUS_NEEDED', title: 'Focus Needed', enabled: true },
    { id: 'OFFICIAL_MARKSHEET', title: 'Official Marksheet', enabled: true },
    { id: 'OMR_SHEET', title: 'OMR Sheet', enabled: true },
    { id: 'PROGRESS_DELTA', title: 'Progress Delta', enabled: true },
    { id: 'MISTAKE_PATTERN', title: 'Mistake Pattern Analysis', enabled: true },
    { id: 'TOPIC_BREAKDOWN', title: 'Topic Breakdown', enabled: true },
    { id: 'TOPIC_DIST', title: 'Topic Strength Distribution', enabled: true },
    { id: 'DOWNLOAD_ANALYSIS', title: 'Download Full Analysis', enabled: true },
    { id: 'REQUEST_CONTENT', title: 'Requested Content', enabled: true },
    { id: 'f4', title: 'Weekly Tests', enabled: true },
    { id: 'f5', title: 'Live Leaderboard', enabled: true },
    { id: 'f6', title: 'Engagement Rewards', enabled: true },
    { id: 'f7', title: 'Universal Chat', enabled: true },
    { id: 'f8', title: 'Private Admin Support', enabled: true },
    { id: 'f9', title: 'Spin Wheel Game', enabled: true },
    { id: 'f10', title: 'Credit System', enabled: true },
    { id: 'f11', title: 'Subscription Plans', enabled: true },
    { id: 'f12', title: 'Store', enabled: true },
    { id: 'f13', title: 'Profile Customization', enabled: true },
    { id: 'f14', title: 'Study Timer', enabled: true },
    { id: 'f15', title: 'Streak System', enabled: true },
    { id: 'f16', title: 'User Inbox', enabled: true },
    { id: 'f17', title: 'Admin Dashboard', enabled: true },
    { id: 'f18', title: 'Content Manager', enabled: true },
    { id: 'f19', title: 'Bulk Upload', enabled: true },
    { id: 'f20', title: 'Security System', enabled: true },
    { id: 'f21', title: 'Performance History', enabled: true },
    { id: 'f22', title: 'Dark/Light Mode', enabled: true },
    { id: 'f23', title: 'Responsive Design', enabled: true },
    { id: 'f25', title: 'Auto-Sync', enabled: true },
    { id: 'f26', title: 'Offline Capabilities', enabled: true },
    { id: 'f28', title: 'Passwordless Login', enabled: true },
    { id: 'f29', title: 'Custom Subjects', enabled: true },
    { id: 'f30', title: 'Gift Codes', enabled: true },
    { id: 'f31', title: 'Featured Shortcuts', enabled: true },
    { id: 'f32', title: 'Notice Board', enabled: true },
    { id: 'f33', title: 'Startup Ad', enabled: true },
    { id: 'f34', title: 'External Apps', enabled: true },
    { id: 'f35', title: 'Activity Log', enabled: true },
    { id: 'f36', title: 'AI Question Generator', enabled: true },
    { id: 'f37', title: 'Payment Gateway Integration', enabled: true },
    { id: 'f38', title: 'Class Management', enabled: true },
    { id: 'f39', title: 'Stream Support', enabled: true },
    { id: 'f40', title: 'Board Support', enabled: true },
    { id: 'f41', title: 'Multi-Language Support', enabled: true },
    { id: 'f42', title: 'Fast Search', enabled: true },
    { id: 'f43', title: 'Recycle Bin', enabled: true },
    { id: 'f44', title: 'Data Backup', enabled: true },
    { id: 'f45', title: 'Deployment Tools', enabled: true },
    { id: 'f46', title: 'Role Management', enabled: true },
    { id: 'f47', title: 'Ban System', enabled: true },
    { id: 'f48', title: 'Impersonation Mode', enabled: true },
    { id: 'f49', title: 'Daily Goals', enabled: true },
    { id: 'f50', title: 'Visual Analytics', enabled: true },
    { id: 'f51', title: 'Detailed Marksheet', enabled: true },
    { id: 'f52', title: 'Question Analysis', enabled: true },
    { id: 'f53', title: 'Time Management Stats', enabled: true },
    { id: 'f54', title: 'Subject Wise Progress', enabled: true },
    { id: 'f55', title: 'Topic Strength Meter', enabled: true },
    { id: 'f56', title: 'Weakness Detector', enabled: true },
    { id: 'f57', title: 'Video Resume', enabled: true },
    { id: 'f58', title: 'PDF Bookmark', enabled: true },
    { id: 'f59', title: 'Night Mode Reading', enabled: true },
    { id: 'f60', title: 'Text-to-Speech Notes', enabled: true },
    { id: 'f61', title: 'Search within PDF', enabled: true },
    { id: 'f62', title: 'Video Quality Control', enabled: true },
    { id: 'f63', title: 'Playback Speed Control', enabled: true },
    { id: 'f64', title: 'Picture-in-Picture Mode', enabled: true },
    { id: 'f65', title: 'Background Audio Play', enabled: true },
    { id: 'f66', title: 'Live Class Integration', enabled: true },
    { id: 'f67', title: 'Recorded Sessions', enabled: true },
    { id: 'f68', title: 'Doubt Clearing', enabled: true },
    { id: 'f69', title: 'Assignment Submission', enabled: true },
    { id: 'f70', title: 'Peer Comparison', enabled: true },
    { id: 'f71', title: 'Global Rank', enabled: true },
    { id: 'f72', title: 'State Rank', enabled: true },
    { id: 'f73', title: 'School Rank', enabled: true },
    { id: 'f74', title: 'Badges & Achievements', enabled: true },
    { id: 'f75', title: 'Referral System', enabled: true },
    { id: 'f76', title: 'Social Share', enabled: true },
    { id: 'f77', title: 'In-App Feedback', enabled: true },
    { id: 'f78', title: 'Bug Reporting', enabled: true },
    { id: 'f79', title: 'Feature Request', enabled: true },
    { id: 'f80', title: 'Privacy Control', enabled: true },
    { id: 'f81', title: 'Account Deletion', enabled: true },
    { id: 'f82', title: 'Data Export', enabled: true },
    { id: 'f83', title: 'Login History', enabled: true },
    { id: 'f84', title: 'Device Management', enabled: true },
    { id: 'f85', title: 'Session Timeout', enabled: true },
    { id: 'f86', title: 'Two-Factor Auth', enabled: true },
    { id: 'f87', title: 'Parent Connect', enabled: true },
    { id: 'f88', title: 'Attendance Tracker', enabled: true },
    { id: 'f89', title: 'Fee Management', enabled: true },
    { id: 'f90', title: 'Library Management', enabled: true },
    { id: 'f91', title: 'Transport Tracker', enabled: true },
    { id: 'f92', title: 'Hostel Management', enabled: true },
    { id: 'f93', title: 'Event Calendar', enabled: true },
    { id: 'f94', title: 'Holiday List', enabled: true },
    { id: 'f95', title: 'Exam Schedule', enabled: true },
    { id: 'f96', title: 'Result Publication', enabled: true },
    { id: 'f97', title: 'Syllabus Tracker', enabled: true },
    { id: 'f98', title: 'Lesson Planner', enabled: true },
    { id: 'f99', title: 'Teacher Remarks', enabled: true },
    { id: 'f100', title: 'Student Diary', enabled: true },
    { id: 'f101', title: 'AI Tutor', enabled: true },
    { id: 'f102', title: 'Voice Search', enabled: true },
    { id: 'f103', title: 'Gesture Control', enabled: true }
];

export const LEVEL_UNLOCKABLE_FEATURES = [
    { id: 'MCQ_PRACTICE', label: 'MCQ Practice Zone' },
    { id: 'AUDIO_LIBRARY', label: 'Audio Library & Podcasts' },
    { id: 'AI_GENERATOR', label: 'AI Notes Generator' },
    { id: 'GAMES', label: 'Games & Spin Wheel' },
    { id: 'COMPETITION_MODE', label: 'Competition Mode' },
    { id: 'ADVANCED_ANALYSIS', label: 'Advanced Analysis' },
    { id: 'REVISION_HUB', label: 'Revision Hub Access' },
    { id: 'WEEKLY_TESTS', label: 'Weekly Tests' }
];

export const LEVEL_UP_CONFIG = [
    { level: 1,  featureId: 'BASIC_ACCESS',  label: 'App Access',          description: 'Video Lectures, Notes & MCQ Practice' },
    { level: 2,  featureId: 'DAILY_LIMITS',  label: 'Daily Limits Up',     description: 'MCQ/PDF/Video daily limits increase at every level' },
    { level: 3,  featureId: 'DISCOUNT_3',    label: '2% Store Discount',   description: 'Purchases pe automatic 2% discount milega' },
    { level: 4,  featureId: 'NAME_COLOR',    label: 'Colored Username',    description: 'Leaderboard mein aapka naam color mein dikhega' },
    { level: 5,  featureId: 'DISCOUNT_5',    label: '5% Store Discount',   description: 'Store pe 5% off — coins, subscriptions sab' },
    { level: 6,  featureId: 'BONUS_LOGIN',   label: 'Bonus Login Credits', description: 'Sunday streak recovery pe extra credits milenge' },
    { level: 7,  featureId: 'DISCOUNT_10',   label: '10% Store Discount',  description: 'Store pe 10% off — L7 Master badge unlock' },
    { level: 8,  featureId: 'DISCOUNT_13',   label: '13% Store Discount',  description: 'GrandMaster tier — naam gold mein dikhega' },
    { level: 9,  featureId: 'NOTES_UNLIM',   label: 'Unlimited Notes/TTS', description: 'L9+ par Notes aur TTS sessions unlimited ho jaate hain' },
    { level: 10, featureId: 'DISCOUNT_20',   label: '20% Store Discount',  description: 'Mythic Crown — sabse bada regular discount' },
    { level: 11, featureId: 'SUPREME',       label: 'Supreme Title',       description: '20% discount + legendary top-bar animation' },
    { level: 12, featureId: 'LEGEND',        label: 'Legend Title',        description: '22% discount + violet nama color' },
    { level: 13, featureId: 'IMMORTAL',      label: 'Immortal Title',      description: '25% discount + pink name color' },
    { level: 14, featureId: 'DIVINE',        label: 'Divine Title',        description: '28% discount + rose name color' },
    { level: 15, featureId: 'ABSOLUTE',      label: 'Absolute — MAX',      description: '30% discount + white glowing name — highest level' },
];

export const NSTA_DEFAULT_FEATURES = [
    { category: '⭐ PAGE 1', id: 'LEADER_BOARD', label: 'Leader Board', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'READING_MODE', label: 'Reading mode', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'WRITING_MODE', label: 'Writing mode', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'MCQ_MODE', label: 'Mcq mode', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'PROJECTOR_MODE', label: 'Projector mode', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'FLASHCARD', label: 'Flashcard', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'PDF', label: 'Pdf', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'VIDEO', label: 'Video', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'SOLUTION_MCQ', label: 'Solution (Mcq)', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'OFFICIAL_MARKSHEET', label: 'Official Marksheet', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'FULL_ANALYSIS', label: 'Full Analysis', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'REVISION_HUB', label: 'Revision Hub', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'ROUTINE', label: 'Routine', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'COMMUNITY', label: 'Community', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'GLOBAL_MESSAGE', label: 'Global message', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'MCQ', label: 'Mcq', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'HELP_ADMIN', label: 'Help (Admin support)', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'THEME_STUDIO', label: 'Theme Studio', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'SCORE_HISTORY', label: 'Score History', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'ROUTINE_COMPILATION', label: 'Routine multiple Books compilation', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'NSTA_MESSENGER', label: 'Nsta messenger', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'DAILY_LIMITE', label: 'Daily limite', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'VP_MULTIPLAYER', label: 'Vp multiplayer', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'CREDIT_DISCOUNT', label: 'Credit Discount', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'FONT_STYLE_COLOR', label: 'Font & style color', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'OFFLINE_DOWNLOAD', label: 'Offline Download', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'DAILY_CLAIM', label: 'Daily claim', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '⭐ PAGE 1', id: 'STORE_DISCOUNT', label: 'Store discount', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '🚀 PAGE 2', id: 'WRITING_CORRECTION', label: 'Writing & Correction mode', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '🚀 PAGE 2', id: 'BASIC_THEME', label: 'Basic Theme', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '🚀 PAGE 2', id: 'ULTRA_THEME', label: 'Ultra Theme', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '🚀 PAGE 2', id: 'MCQ_LIMITE', label: 'Mcq limite', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 },
    { category: '🚀 PAGE 2', id: 'NAME_CHANGE', label: 'Name change', visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'], limits: {}, creditCost: 0 }
];

export const DEFAULT_PLAN_COMPARISON = [
    {
        name: "1. CORE LEARNING FEATURES",
        features: [
            { id: 'NOTES_LIB', name: "PDF Notes Library", free: "🔒 First 2 Chapters", basic: "✅ Unlimited", ultra: "✅ Unlimited" },
            { id: 'VIDEO_ACCESS', name: "Video Lectures", free: "🔒 First 2 Videos", basic: "✅ Unlimited", ultra: "✅ Unlimited" },
            { id: 'TOPIC_CONTENT', name: "Topic-wise Notes", free: "❌ Locked", basic: "✅ Full Access", ultra: "✅ Full Access" },
            { id: 'AUDIO_LIBRARY', name: "Audio / Podcast", free: "❌ Locked", basic: "❌ Locked", ultra: "✅ Premium Only" },
            { id: 'QUICK_REVISION', name: "Quick Revision", free: "✅ Basic", basic: "✅ Full", ultra: "✅ Full" },
            { id: 'DEEP_DIVE', name: "Deep Dive Notes", free: "❌ Locked", basic: "✅ Yes", ultra: "✅ Yes" },
            { id: 'PREMIUM_NOTES', name: "Premium Notes", free: "❌ Locked", basic: "✅ Yes", ultra: "✅ Yes" },
            { id: 'CLASS_NOTES_TIER', name: "Class 6-12 Notes Content", free: "📖 Book Text only", basic: "📝 Book Text + Smart Notes", ultra: "💡 Smart Notes + Explanation" },
            { id: 'ADDITIONAL_NOTES', name: "Additional Resources", free: "❌ Locked", basic: "✅ Yes", ultra: "✅ Yes" },
            { id: 'SEARCH', name: "Search Capability", free: "✅ Basic", basic: "✅ Advanced", ultra: "✅ Advanced" },
            { id: 'OFFLINE_SYNC', name: "Save / Offline Mode", free: "❌ No", basic: "✅ Yes", ultra: "✅ Yes" },
        ]
    },
    {
        name: "2. REVISION HUB (USP)",
        features: [
            { id: 'REVISION_HUB', name: "Revision Hub Access", free: "❌ Locked", basic: "⚠️ 1 Day/Week", ultra: "✅ Daily" },
            { id: 'WEAK_SORT', name: "Weak/Avg/Strong Sorting", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'EXCELLENT_TAB', name: "Excellent (80%+) Tab", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'AI_PLAN', name: "Auto AI Plan", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'MISTAKE_PATTERN', name: "Mistake Pattern Analysis", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'MASTERY_30', name: "30-Day Mastery Logic", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'START_TODAY', name: "One-Click \"Start Today\"", free: "❌ No", basic: "⚠️ Limited", ultra: "✅ Yes" }
        ]
    },
    {
        name: "3. MCQ SYSTEM",
        features: [
            { id: 'MCQ_FREE', name: "Daily MCQ Limit", free: "30 Questions", basic: "50 Questions", ultra: "100 Questions" },
            { id: 'EXAM_MODE', name: "Exam Mode Timer", free: "❌ No", basic: "✅ Yes", ultra: "✅ Yes" },
            { id: 'SOLUTIONS', name: "Detailed Solutions", free: "❌ Only Right/Wrong", basic: "✅ Text Solution", ultra: "✅ AI Explanation" },
            { id: 'RE_ATTEMPT', name: "Re-attempt Wrong", free: "❌ No", basic: "✅ Yes", ultra: "✅ Instant" },
            { id: 'TOPIC_MCQ', name: "Topic-wise Bulk MCQ", free: "❌ No", basic: "⚠️ Limited", ultra: "✅ Full Access" },
            { id: 'MCQ_HISTORY', name: "History & Logs", free: "⚠️ 3 Days", basic: "✅ Full History", ultra: "✅ Full History" },
            { id: 'PALETTE', name: "Question Palette", free: "✅ Yes", basic: "✅ Yes", ultra: "✅ Yes" }
        ]
    },
    {
        name: "4. AI & SMART FEATURES",
        features: [
            { id: 'AI_CHAT', name: "AI Tutor Chat", free: "❌ No", basic: "🔒 5 Chats/day", ultra: "✅ Unlimited" },
            { id: 'SMART_SORT', name: "Smart Topic Sorting", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'WEAK_DETECT', name: "Weakness Detection", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'DYN_PLAN', name: "Dynamic Study Plan", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'AI_STUDIO', name: "AI Studio", free: "❌ No", basic: "❌ No", ultra: "✅ Full Access" }
        ]
    },
    {
        name: "5. TTS / STUDY TOOLS",
        features: [
            { id: 'TTS_FEATURE', name: "Text-to-Speech (TTS)", free: "⚠️ 1 min demo", basic: "✅ Unlimited", ultra: "✅ Unlimited" },
            { id: 'SPEED_CTRL', name: "Speed Control", free: "❌ No", basic: "❌ No", ultra: "✅ 0.5x – 2x" },
            { id: 'AUTO_SCROLL', name: "Auto Scroll", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'FOCUS_MODE', name: "Focus Mode", free: "❌ No", basic: "✅ Yes", ultra: "✅ Yes" },
            { id: 'STUDY_TIMER', name: "Study Timer", free: "✅ Basic", basic: "✅ Analytics", ultra: "✅ Analytics" }
        ]
    },
    {
        name: "6. GAMIFICATION & ECONOMY",
        features: [
            { id: 'COINS', name: "Coins / Credits Earning", free: "✅ Normal", basic: "✅ 1.5x Multiplier", ultra: "✅ 3x Multiplier" },
            { id: 'SPIN_WIN', name: "Spin & Win", free: "1 per day", basic: "5 per day", ultra: "10 per day" },
            { id: 'STREAK', name: "Daily Streak Protection", free: "✅ Yes", basic: "✅ Yes", ultra: "✅ Freeze (No loss)" },
            { id: 'LEADERBOARD', name: "Leaderboard Access", free: "View Only", basic: "Participate", ultra: "Top Badge" },
            { id: 'DOUBLE_CREDIT', name: "Double Credit Events", free: "❌ No", basic: "⚠️ Sometimes", ultra: "✅ Always Active" }
        ]
    },
    {
        name: "7. CONTENT REQUEST SYSTEM",
        features: [
            { id: 'REQUEST_CONTENT', name: "Request New Content", free: "❌ No", basic: "✅ Yes", ultra: "✅ VIP Access" },
            { id: 'PRIORITY_REQ', name: "Priority Level", free: "Low", basic: "Normal", ultra: "Top Priority" },
            { id: 'ADMIN_PROMISE', name: "Admin Promise", free: "❌ No", basic: "❌ No", ultra: "24h Delivery" }
        ]
    },
    {
        name: "8. ACCOUNT & SECURITY",
        features: [
            { id: 'DEVICE_LIMIT', name: "Device Login Limit", free: "1 Device", basic: "1 Device", ultra: "Multi-Device" },
            { id: 'GHOST_LOGIN', name: "Ghost Login (Admin)", free: "❌ No", basic: "❌ No", ultra: "✅ Yes" },
            { id: 'PROFILE_EDIT', name: "Profile Edit", free: "Basic Info", basic: "Full Profile", ultra: "Full Profile" }
        ]
    },
    {
        name: "9. ADMIN POWER (ULTRA EXCLUSIVE)",
        features: [
            { id: 'LIVE_SPY', name: "Live User Spy", free: "❌ No", basic: "❌ No", ultra: "✅ Active" },
            { id: 'LOGIN_AS', name: "Login As User", free: "❌ No", basic: "❌ No", ultra: "✅ Active" },
            { id: 'NOTIFICATIONS', name: "Targeted Notifications", free: "❌ No", basic: "❌ No", ultra: "✅ Active" },
            { id: 'FLASH_SALE', name: "Flash Sale Auto Trigger", free: "❌ No", basic: "❌ No", ultra: "✅ Active" },
            { id: 'ABANDON_DISC', name: "Payment Abandon Discount", free: "❌ No", basic: "❌ No", ultra: "✅ Active" },
            { id: 'CREDIT_PANEL', name: "Credit Control Panel", free: "❌ No", basic: "❌ No", ultra: "✅ Active" }
        ]
    }
];

export const STUDENT_APP_FEATURES = ALL_APP_FEATURES.filter(f =>
    !['f17', 'f18', 'f19', 'f20', 'f34', 'f37', 'f43', 'f44', 'f45', 'f46', 'f47', 'f48', 'f89', 'f90', 'f91', 'f92', 'f88', 'f87'].includes(f.id)
);
